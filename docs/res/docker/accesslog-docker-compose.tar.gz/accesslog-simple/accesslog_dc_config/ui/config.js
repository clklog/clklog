window.globalConfig = {
  BASE_API: "/api", // 这里可以根据需要覆盖或者扩展配置
  projectList: [  //根据需要配置项目
    {
      value: "clklogapp",
      label: "clklog",
    }
  ],
};