#!/bin/bash

mkdir -p accesslog_dc_data/redis
chown 999 accesslog_dc_data/redis
mkdir -p   accesslog_dc_data/processing/checkpoints
chown 9999 accesslog_dc_data/processing/checkpoints
chgrp 9999 accesslog_dc_data/processing/checkpoints
mkdir -p   accesslog_dc_data/zookeeper
chown 1001 accesslog_dc_data/zookeeper
chgrp 1001 accesslog_dc_data/zookeeper
mkdir -p   accesslog_dc_data/kafka
chown 1001 accesslog_dc_data/kafka
chgrp 1001 accesslog_dc_data/kafka
